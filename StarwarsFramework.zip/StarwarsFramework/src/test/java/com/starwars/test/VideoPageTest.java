package com.starwars.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.starwars.pages.VideoPage;
import com.starwars.utility.ActionClass;

public class VideoPageTest {
	WebDriver driver=null;
	VideoPage vp = new VideoPage(driver);
	ActionClass ac = new ActionClass(driver);
	
	@Test
	public void verifyVideoCurrentUrl() {
		if (driver.getCurrentUrl() == vp.videoPageUrl) {
			System.out.println("Video Page Current URL and expected Current Url matched ");
		} else {
			System.out.println("Video Current URL mismatched ");
		}
	}
	@Test
	public void videoVerifySearch() {
		vp.videoSearch().sendKeys("");
		vp.videoSearchButton().click();
		vp.videoSearchButton().isEnabled();
		System.out.println(driver.getCurrentUrl());
		driver.navigate().back();

	}

	@Test
	public void verifySearchButtonEnabled() {
		System.out.println(" videoSearchButtonEnabled is enabled : " + vp.videoSearchButton().isEnabled());

	}

	

}

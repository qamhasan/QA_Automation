package com.starwars.test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.starwars.pages.HomePage;
import com.starwars.pages.LoginPage;

public class LoginPageTest {
	WebDriver driver = null;
	LoginPage lp = new LoginPage(driver);
	HomePage hp = new HomePage(driver);

	public Properties propLoad() throws IOException {
		Properties prop = new Properties();// Properties is class in Java
		FileInputStream fis = new FileInputStream(
				"C:\\Users\\dpp540\\workspace\\StarwarsFramework\\src\\test\\java\\com\\starwars\\test\\datadriven.properties");
		// by using FileInputStream java class we are passing the properties file path
		// into variable to get the properties

		prop.load(fis);// loading the file into class
		return prop;

	}

	@Parameters({ "url" })
	@BeforeTest
	public void startBrowser(Properties prop) throws IOException {

		if (prop.getProperty("browser").equals("firefox")) {
			System.setProperty(prop.getProperty("geckodriver"), prop.getProperty("geckodriverPath"));
			driver = new FirefoxDriver();
			driver.get("url");
		} else if (prop.getProperty("browser").equals("chrome")) {
			System.setProperty(prop.getProperty("chromedriver"), prop.getProperty("chromedriverPath"));
			driver = new ChromeDriver();
			driver.get("url");
		} else {
			driver = new InternetExplorerDriver();
			System.out.println("No executable file found for Browser");
			driver.get("url");
		}
		// driver.get("https://www.starwars.com/");
		// driver.manage().deleteAllCookies();
		// driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		// driver.get("url");

	}

	@Parameters({ "username", "password" })
	@Test(groups = { "Smoke" })
	public void signIn(String username, String password) {
		hp.logIn().click();// clicking on log in from home page
		System.out.println("login from homepage");

		System.out.println(username);
		lp.emailAdress().sendKeys(username);// passing the username from xml

		System.out.println(password);
		lp.password().sendKeys(password);// passing the password from xml
		lp.signInButton().click();

		System.out.println(lp.disId().getText());// printing the user id
		System.out.println("loogedin successfully");

	}

	@Test
	public void createAnAccount() {
		lp.createAnAcount().click();
		driver.navigate().to("https://www.starwars.com");

	}

	@AfterTest
	public void endBrowser() {
		driver.quit();
	}
}

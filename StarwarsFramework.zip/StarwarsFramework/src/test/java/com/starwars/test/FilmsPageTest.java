package com.starwars.test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.starwars.pages.FilmsPage;

public class FilmsPageTest {
	WebDriver driver = null;
	FilmsPage fp = new FilmsPage(driver);

	@Test
	public void verifyFilmsCurrentUrl() {
		if (driver.getCurrentUrl() == fp.filmsPageUrl) {
			System.out.println("Films Page Current URL and expected Current Url matched ");
		} else {
			System.out.println("Films  Current URL mismatched ");
		}

	}

	@Test
	public void verifySectionTitleText() {
		if (fp.filmSectionTitle().getText() == fp.SectionTitleText) {
			System.out.println("Films Section Title Text matched");
		}
	}

	@Test
	public void verifySectionTitleDisplay() {
		System.out.println("Section title displayed:" + fp.filmSectionTitle().isDisplayed());

	}

	@Test
	public void buyNow() {
		fp.buyNow().click();
		System.out.println("clciking to buy now i Films Page");
		System.out.println(driver.getCurrentUrl());
		driver.navigate().to(fp.filmsPageUrl);

	}

}

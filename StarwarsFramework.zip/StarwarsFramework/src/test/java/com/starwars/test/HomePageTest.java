package com.starwars.test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.starwars.pages.HomePage;
import com.starwars.pages.LoginPage;
import com.starwars.utility.ActionClass;

public class HomePageTest {
	WebDriver driver = null;
	LoginPage lp = new LoginPage(driver);
	HomePage hp = new HomePage(driver);
	ActionClass ac=new ActionClass(driver);
	

	@Test
	public void verifyHomePageLogInText() {
		System.out.println(" Home page Log In text : " + hp.logIn().getText());

	}

	@Test
	public void verifyHomePageSignupText() {
		System.out.println(" Home page sign up text : " + hp.signUp().getText());

	}

	@Test
	public void verifySearch() {
		hp.search().sendKeys("DEATH STICKS");
		hp.searchButton().click();
		System.out.println(driver.getCurrentUrl());
		driver.navigate().back();

	}

	@Test
	public void searchButtonEnabled() {
		System.out.println(" searchButton is enabled : " + hp.searchButton().isEnabled());

	}
	@Test
	public void pageScrolling()

	{
		ac.scrollByPixel();
	}
}

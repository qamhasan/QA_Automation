package com.starwars.utility;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class ActionClass {

	WebDriver driver;

	public ActionClass(WebDriver driver) {
		this.driver = driver;
	}

	public Object takeSnapShot(WebDriver driver, String fileWithPath) throws Exception {

		// Converting driver object to TakeScreenshot

		TakesScreenshot scrShot = ((TakesScreenshot) driver);

		// Calling getScreenshotAs method to create image file

		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);

		// Moving image file to new destination

		File DestFile = new File(fileWithPath);

		// Copying file at destination

		FileUtils.copyFile(SrcFile, DestFile);

		return this.takeSnapShot(driver, fileWithPath);

	}

	public By getLocator(String identifyBy, String locator) throws Exception {

		if (identifyBy.equalsIgnoreCase("xpath")) {
			return By.xpath(locator);
		} else if (identifyBy.equalsIgnoreCase("id")) {
			return By.id(locator);
		} else if (identifyBy.equalsIgnoreCase("name")) {
			return By.name(locator);
		} else if (identifyBy.equalsIgnoreCase("linkText")) {
			return By.linkText(locator);
		} else if (identifyBy.equals("partialLinkText")) {
			return By.partialLinkText(locator);
		} else if (identifyBy.equals("cssSelector")) {
			return By.cssSelector(locator);
		} else if (identifyBy.equals("className")) {
			return By.className(locator);
		} else {
			throw new Exception("No such locator: " + locator);
		}

	}
	/*
	 * public void hover() { Actions action = new Actions(driver); WebElement we =
	 * driver.findElement(By.xpath("html/body/div[13]/ul/li[4]/a"));
	 * action.moveToElement(we).moveToElement(driver.findElement(By.xpath(
	 * "/expression-here"))).click().build().perform(); }
	 */

	public Actions mouseOver(String identifyBy, String locator) throws Throwable {

		Actions action = new Actions(driver);
		WebElement element = driver.findElement(getLocator(identifyBy, locator));
		action.moveToElement(element).build().perform();
		Thread.sleep(2000);
		return action;

	}
	public Object scrollByPixel() {
       // System.setProperty("webdriver.chrome.driver", "chromePath);
       /* driver = new ChromeDriver();*/

        JavascriptExecutor js = (JavascriptExecutor) driver;

        // Launch the application		
       // driver.get("http://www.starwars.com");

        //To maximize the window. This code may not work with Selenium 3 jars. If script fails you can remove the line below		
       //driver.manage().window().maximize();

        // This  will scroll down the page by  1000 pixel vertical		
        return js.executeScript("window.scrollBy(0,1000)");
        
    }

}

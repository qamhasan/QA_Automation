package com.starwars.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	WebDriver driver;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	By signIn = By.xpath("//*[@id=\"nav-utility\"]/div[2]/div[1]/div[1]");

	By userNamePath = By
			.xpath("//*[@id=\"did-ui-view\"]/div/section/section/form/section/div[1]/div/label/span[2]/input");

	By passwordPath = By
			.xpath("//*[@id=\"did-ui-view\"]/div/section/section/form/section/div[2]/div/label/span[2]/input");

	By signInButtonPath = By.xpath("//*[@id=\"did-ui-view\"]/div/section/section/form/section/div[3]/button");

	By signInWithFacebook = By.xpath("//*[@id=\"did-ui-view\"]/div/section/section/form/section/div[5]/a[1]");

	By signInWithGoogle = By.xpath("//*[@id=\"did-ui-view\"]/div/section/section/form/section/div[5]/a[2]");

	By afterLoginDisid = By.xpath("//*[@id=\"nav-utility\"]/div[2]/div[2]/div[1]/span[1]");

	By createAnAccount = By.xpath("//*[@id=\"did-ui-view\"]/div/section/section/form/section/div[6]/a");

	public WebElement emailAdress() {
		return driver.findElement(userNamePath);

	}

	public WebElement password() {
		return driver.findElement(passwordPath);

	}

	public WebElement signInButton() {
		return driver.findElement(signInButtonPath);

	}

	public WebElement disId() {
		return driver.findElement(signInButtonPath);

	}

	public WebElement signInWithFacebook() {
		return driver.findElement(signInWithFacebook);

	}

	public WebElement signInWithGoogle() {
		return driver.findElement(signInWithGoogle);

	}

	public WebElement createAnAcount() {
		return driver.findElement(createAnAccount);

	}

}
package com.starwars.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class FilmsPage {

	WebDriver driver;
	public String filmsPageUrl = "https://www.starwars.com/films";

	public String SectionTitleText = "Solo: A Star Wars Story Makes the Jump Home";

	public FilmsPage(WebDriver driver) {
		this.driver = driver;
	}

	By filmsSectionTitle = By.xpath("//*[@id=\"countdown\"]/ol/li/div[4]/span");

	By buyNow = By.xpath("//*[@id=\"countdown\"]/ol/li/div[2]/div/a");

	By videoSearchButton = By.xpath("//*[@id=\"main\"]/div/div/section/form/div[2]/span/input");

	public WebElement filmSectionTitle() {
		return driver.findElement(filmsSectionTitle);

	}

	public WebElement buyNow() {
		return driver.findElement(buyNow);

	}

}

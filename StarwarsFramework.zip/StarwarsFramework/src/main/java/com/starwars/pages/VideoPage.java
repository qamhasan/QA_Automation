package com.starwars.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class VideoPage {
	
	WebDriver driver;
	public String videoPageUrl="https://www.starwars.com/video";
	

	public VideoPage(WebDriver driver) {
		this.driver = driver;
	}
	
	By videoSearch = By.xpath("//*[@id=\"ref-1-0\"]/div/form/div[2]/input[1]");
	By videoSearchList=By.xpath("//*[@id=\"nav-ac\"]/li");//in order to get the video ,match with the video search text then click
	By videoSearchButton=By.xpath("//*[@id=\"main\"]/div/div/section/form/div[2]/span/input");
	
	public WebElement videoSearch() {
		return driver.findElement(videoSearch);

	}
	public WebElement videoSearchList() {
		return driver.findElement(videoSearchList);

	}
	public WebElement videoSearchButton() {
		return driver.findElement(videoSearchButton);

	}
	
	
	

}

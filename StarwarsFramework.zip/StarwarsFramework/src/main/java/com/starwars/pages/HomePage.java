package com.starwars.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
WebDriver driver;
public String homePageUrl="https://www.starwars.com";
	public HomePage(WebDriver driver)
	{
		this.driver=driver;
	}
	By logIn = By.xpath("//*[@id=\"nav-utility\"]/div[2]/div[1]/div[1]");
	By signUp = By.xpath("//*[@id=\"nav-utility\"]/div[2]/div[1]/div[1]");
	By search = By.id("nav-search-input");
	By searchButton = By.id("nav-search-icon");
	By navSection = By.xpath("//*[@id='nav-content']");
	By navSectionLink = By.xpath("//*[@id='nav-content']//ul/li");

	// tag name[contains(@property name,'part of value')]
	// b[contains(@type,'')]
	// By navNewsAndBlog = By.xpath("//a[contains(@class, 'news-content')]");
	// nav/ul//li[0]/a
	By navFilms = By.xpath("//*[@id=\"section-links\"]/li[4]/a");
	By navVideos = By.xpath("//a[contains(@class, 'video-content')]");
	
	public WebElement logIn()
	{
		return driver.findElement(logIn);
	
	}
	public WebElement signUp()
	{
		return driver.findElement(signUp);
	
	}

	public WebElement search()
	{
		return driver.findElement(search);
	
	}
	public WebElement searchButton()
	{
		return driver.findElement(searchButton);
	
	}
	public WebElement navSection()
	{
		return driver.findElement(navSection);
	
	}
	public WebElement navSectionLink()
	{
		return driver.findElement(navSectionLink);
	
	}
	
	
	
	

}
